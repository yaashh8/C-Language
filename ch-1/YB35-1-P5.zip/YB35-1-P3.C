#include<stdio.h>
#include<conio.h>
main() {
	clrscr();
	printf("\n\n\n\n\n\n\n\n");
	printf("\t\t   - - -   \n");
	printf("\t\t |       | \n");
	printf("\t\t N       | \n");
	printf("\t\t A       | \n");
	printf("\t\t M       | \n");
	printf("\t\t E       | \n");
	printf("\t\t |       | \n");
	printf("\t\t   - - -   \n");
	getch();
       }