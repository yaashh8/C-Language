#include<stdio.h>
#include<conio.h>
main()  {
	  clrscr();
	  printf("\t\t  * * *  \n");
	  printf("\t\t*       *\n");
	  printf("\t\t*       *\n");
	  printf("\t\t*       *\n");
	  printf("\t\t*       *\n");
	  printf("\t\t*       *\n");
	  printf("\t\t  * * *  \n");
	  getch();
	}