#include<stdio.h>
#include<conio.h>
main()  {
	  clrscr();
	  printf("Name\t\t: Yash Bhakta\n");
	  printf("Age\t\t: 17\n");
	  printf("School\t\t: Shree Swaminarayan Mission School\n");
	  getch();
	}
