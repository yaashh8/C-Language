#include<stdio.h>
#include<conio.h>
#define P printf
main() {
	 int l = 5, h = 4;
	 clrscr();
	 P("\n\n\n");
	 P("\t\t\tarea of rectangle : %d", l * h);
	 getch();
}