#include<stdio.h>
#include<conio.h>
#define P printf
#define pi 3.14
main() {
	 int r = 4;
	 clrscr();
	 P("\n\n");
	 P("\t\tarea of circle : %.2f",pi * r * r);
	 getch();
}