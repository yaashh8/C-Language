#include<stdio.h>
#include<conio.h>
#define P printf
main() {
	int p = 50,r = 34,n = 2;
	clrscr();
	P("\n\n\n");
	P("\t\t simple imterest : %d",p * r * n / 100);
	getch();


}