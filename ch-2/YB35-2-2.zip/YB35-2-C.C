#include<stdio.h>
#include<conio.h>
#define P printf
main() {
	  int s = 10;
	  clrscr();
	  P("\n\n\n");
	  P("\t\tarea of squar : %d",s * s);
	  getch();
}