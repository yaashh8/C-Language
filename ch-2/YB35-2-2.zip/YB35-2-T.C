#include<stdio.h>
#include<conio.h>
#define P printf
main()  {
	   int b = 50, h = 25;
	   clrscr();
	   P("\n\n");
	   P("\t\tarea of triangle : %d",0.5 * b * h);
	   getch();
}