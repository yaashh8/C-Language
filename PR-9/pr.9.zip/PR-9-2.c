#include<stdio.h>

enum week{
	sun=1,mon,tue,wed,thu,fri,sat
};

void main(){
	
	printf("day : %d",sun);
	
}
