#include<stdio.h>
#include<conio.h>
main() {
	int x = 3, y = 5,z;
	clrscr();
	z = (x*x*x)+(y*y*y)-(3*x*x*y)-(3*x*y*y);
	printf("z : %d",z);
	getch();
}