#include<stdio.h>
#include<conio.h>
main() {
	int x = 3, y = 5,z = 2,a;
	clrscr();
	z = (x*x*x)-(y*y*y)-(z*z*z)-3*(y+z)*(x-y)*(x-z);
	printf("a : %d",a);
	getch();
}