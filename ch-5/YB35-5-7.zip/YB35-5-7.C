#include<stdio.h>
#include<conio.h>
main() {
	int x = 3, y = 5,z = 2,a;
	clrscr();
	z = (x*x)+(y*y)+(z*z)+(2*x*y)+(2*y*z)+(2*x*z);
	printf("a : %d",a);
	getch();
}