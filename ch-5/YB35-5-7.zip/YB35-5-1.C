#include<stdio.h>
#include<conio.h>
main() {
	int x = 3, y = 5,z;
	clrscr();
	z = (x*x)+(2*x*y)+(y*y);
	printf("z : %d",z);
	getch();
}