#include<stdio.h>
#include<conio.h>
main() {
	 int x = 2 , y = 4, z;
	 clrscr();
	 z = (x*x)-(2*x*y)+(y*y);
	 printf("z : %d",z);
	 getch();

}