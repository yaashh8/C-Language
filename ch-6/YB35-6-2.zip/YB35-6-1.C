#include<stdio.h>
#include<conio.h>
main() {
	 int a,b;
	 clrscr();
	 printf("enter value of a :");
	 scanf("%d",&a);
	 printf("enter value of b :");
	 scanf("%d",&b);
	 if (a<b) {
	      printf("the value of a is small.");
	 }
	 else {
	       printf("the value of b is small.");
	     }
	     getch();
       }


